This dockerfile is used to build an image for the profile IRSA tests for the Katib component.

It is currently being hosted at `public.ecr.aws/z1j2m4o4/kubeflow-katib-mxnet-mnist:latest`.
